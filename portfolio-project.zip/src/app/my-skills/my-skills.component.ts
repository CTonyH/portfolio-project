import { Component } from '@angular/core';

@Component({
  selector: 'app-my-skills',
  imports: [],
  standalone: true,
  templateUrl: './my-skills.component.html',
  styleUrl: './my-skills.component.scss'
})
export class MySkillsComponent {

}
